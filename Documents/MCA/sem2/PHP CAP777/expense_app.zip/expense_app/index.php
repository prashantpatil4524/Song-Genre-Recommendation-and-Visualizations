<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$user    = $_SESSION['user'];
$file    = 'data_' . $user . '.json';  // per-user data file

// Unit III: Arrays in PHP - load records
$records = [];
if (file_exists($file)) {
    $records = json_decode(file_get_contents($file), true) ?? [];
}

// Unit IV: Capturing HTML form data using PHP
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    // Unit II: Built-in + user defined functions
    function sanitize($val) {
        return htmlspecialchars(trim($val));
    }

    if ($action === 'add') {
        $type     = $_POST['type']        ?? 'expense';
        $item     = sanitize($_POST['item']     ?? '');
        $amount   = floatval($_POST['amount']   ?? 0);
        $category = sanitize($_POST['category'] ?? 'Other');
        $date     = sanitize($_POST['date']     ?? date('Y-m-d'));

        if ($item !== '' && $amount > 0) {
            $records[] = [
                'id'       => uniqid(),
                'type'     => $type,
                'item'     => $item,
                'amount'   => $amount,
                'category' => $category,
                'date'     => $date,
            ];
            file_put_contents($file, json_encode($records));
        }
    }

    if ($action === 'delete') {
        $id      = $_POST['id'] ?? '';
        $records = array_values(array_filter($records, fn($r) => $r['id'] !== $id));
        file_put_contents($file, json_encode($records));
    }

    header('Location: index.php');
    exit;
}

// Unit I: Variables + Unit III: Array operations
$total_expense = 0;
$total_earning = 0;

// Unit I: Looping statements
foreach ($records as $r) {
    if ($r['type'] === 'expense') $total_expense += $r['amount'];
    else                          $total_earning  += $r['amount'];
}

$balance = $total_earning - $total_expense;

// Unit III: Sorting arrays
usort($records, fn($a, $b) => strcmp($b['date'], $a['date']));

// Category summary for expenses only
$cat_summary = [];
foreach ($records as $r) {
    if ($r['type'] === 'expense') {
        $cat_summary[$r['category']] = ($cat_summary[$r['category']] ?? 0) + $r['amount'];
    }
}
arsort($cat_summary);  // Unit III: sorting arrays

// Separate lists
$expenses = array_values(array_filter($records, fn($r) => $r['type'] === 'expense'));
$earnings = array_values(array_filter($records, fn($r) => $r['type'] === 'earning'));

// Unit I: Control flow
$balance_color = $balance >= 0 ? '#27ae60' : '#c0392b';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Expense Tracker</title>
</head>
<body style="margin:0; padding:0; background:#f7f7f7; font-family:Arial, sans-serif; font-size:14px; color:#222;">

<!-- Top Nav -->
<div style="background:#c0392b; padding:0 24px; display:flex; align-items:center; justify-content:space-between; height:52px;">
  <h1 style="margin:0; color:#fff; font-size:17px; font-weight:700;">Expense Tracker</h1>
  <div style="display:flex; align-items:center; gap:16px;">
    <span style="color:#ffc; font-size:13px;">Hi, <strong><?= htmlspecialchars($user) ?></strong></span>
    <a href="logout.php" style="color:#fff; font-size:12px; text-decoration:none; border:1px solid rgba(255,255,255,0.5); padding:4px 12px; border-radius:3px;">Logout</a>
  </div>
</div>

<div style="max-width:900px; margin:24px auto; padding:0 16px;">

  <!-- Summary Cards -->
  <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:24px;">

    <div style="background:#fff; border:1px solid #e8e8e8; border-radius:6px; padding:16px 18px; border-top:3px solid #c0392b;">
      <p style="margin:0 0 6px; font-size:11px; color:#999; text-transform:uppercase; letter-spacing:1px;">Total Earned</p>
      <p style="margin:0; font-size:22px; font-weight:700; color:#222;">₹<?= number_format($total_earning, 0) ?></p>
    </div>

    <div style="background:#fff; border:1px solid #e8e8e8; border-radius:6px; padding:16px 18px; border-top:3px solid #c0392b;">
      <p style="margin:0 0 6px; font-size:11px; color:#999; text-transform:uppercase; letter-spacing:1px;">Total Spent</p>
      <p style="margin:0; font-size:22px; font-weight:700; color:#222;">₹<?= number_format($total_expense, 0) ?></p>
    </div>

    <div style="background:#fff; border:1px solid #e8e8e8; border-radius:6px; padding:16px 18px; border-top:3px solid <?= $balance >= 0 ? '#27ae60' : '#c0392b' ?>;">
      <p style="margin:0 0 6px; font-size:11px; color:#999; text-transform:uppercase; letter-spacing:1px;">Balance</p>
      <p style="margin:0; font-size:22px; font-weight:700; color:<?= $balance_color ?>;">
        <?= $balance >= 0 ? '+' : '' ?>₹<?= number_format(abs($balance), 0) ?>
      </p>
    </div>

  </div>

  <!-- Add Entry Form -->
  <div style="background:#fff; border:1px solid #e8e8e8; border-radius:6px; padding:20px 22px; margin-bottom:24px;">

    <h2 style="margin:0 0 16px; font-size:15px; font-weight:700; color:#c0392b; border-bottom:1px solid #f0f0f0; padding-bottom:10px;">Add Entry</h2>

    <!-- Unit IV: HTML form controls + sending data from PHP to HTML -->
    <form method="POST">
      <input type="hidden" name="action" value="add">

      <!-- Row 1 -->
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; margin-bottom:12px;">

        <div>
          <label style="display:block; font-size:12px; color:#666; margin-bottom:5px; font-weight:600;">Type</label>
          <select name="type" style="width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #ccc; border-radius:4px; font-size:13px; background:#fff;">
            <option value="expense">Expense</option>
            <option value="earning">Earning</option>
          </select>
        </div>

        <div>
          <label style="display:block; font-size:12px; color:#666; margin-bottom:5px; font-weight:600;">Item / Description</label>
          <input type="text" name="item" placeholder="e.g. Lunch, Salary" required
            style="width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #ccc; border-radius:4px; font-size:13px;">
        </div>

        <div>
          <label style="display:block; font-size:12px; color:#666; margin-bottom:5px; font-weight:600;">Amount (₹)</label>
          <input type="number" name="amount" placeholder="0" min="1" step="0.01" required
            style="width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #ccc; border-radius:4px; font-size:13px;">
        </div>

      </div>

      <!-- Row 2 -->
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:16px;">

        <div>
          <label style="display:block; font-size:12px; color:#666; margin-bottom:5px; font-weight:600;">Category</label>
          <select name="category" style="width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #ccc; border-radius:4px; font-size:13px; background:#fff;">
            <?php
            // Unit III: Arrays + Unit I: looping
            $cats = ['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Salary', 'Freelance', 'Other'];
            foreach ($cats as $c): ?>
              <option><?= $c ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label style="display:block; font-size:12px; color:#666; margin-bottom:5px; font-weight:600;">Date</label>
          <input type="date" name="date" value="<?= date('Y-m-d') ?>"
            style="width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #ccc; border-radius:4px; font-size:13px;">
        </div>

      </div>

      <button type="submit"
        style="background:#c0392b; color:#fff; border:none; padding:10px 28px; border-radius:4px; font-size:14px; font-weight:600; cursor:pointer;">
        Add Entry
      </button>

    </form>
  </div>

  <!-- Two Column Layout -->
  <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:24px;">

    <!-- Expense Category Summary -->
    <div style="background:#fff; border:1px solid #e8e8e8; border-radius:6px; padding:20px 22px;">
      <h2 style="margin:0 0 14px; font-size:15px; font-weight:700; color:#c0392b; border-bottom:1px solid #f0f0f0; padding-bottom:10px;">Expense by Category</h2>

      <?php if (empty($cat_summary)): ?>
        <p style="color:#bbb; font-size:13px; margin:0;">No expenses yet.</p>
      <?php else: ?>
        <?php foreach ($cat_summary as $cat => $amt):
          $pct = $total_expense > 0 ? round(($amt / $total_expense) * 100) : 0;
        ?>
        <div style="margin-bottom:12px;">
          <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:4px;">
            <span style="font-weight:600;"><?= $cat ?></span>
            <span style="color:#888;">₹<?= number_format($amt, 0) ?> &nbsp;<span style="color:#ccc;"><?= $pct ?>%</span></span>
          </div>
          <div style="height:5px; background:#f0f0f0; border-radius:3px;">
            <div style="height:5px; width:<?= $pct ?>%; background:#c0392b; border-radius:3px;"></div>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Earnings Summary -->
    <div style="background:#fff; border:1px solid #e8e8e8; border-radius:6px; padding:20px 22px;">
      <h2 style="margin:0 0 14px; font-size:15px; font-weight:700; color:#c0392b; border-bottom:1px solid #f0f0f0; padding-bottom:10px;">Earnings (<?= count($earnings) ?>)</h2>

      <?php if (empty($earnings)): ?>
        <p style="color:#bbb; font-size:13px; margin:0;">No earnings added yet.</p>
      <?php else: ?>
        <table style="width:100%; border-collapse:collapse; font-size:13px;">
          <thead>
            <tr style="border-bottom:1px solid #f0f0f0;">
              <th style="text-align:left; padding:6px 0; color:#999; font-weight:600;">Item</th>
              <th style="text-align:left; padding:6px 0; color:#999; font-weight:600;">Date</th>
              <th style="text-align:right; padding:6px 0; color:#999; font-weight:600;">Amount</th>
              <th style="padding:6px 0;"></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($earnings as $e): ?>
            <tr style="border-bottom:1px solid #f9f9f9;">
              <td style="padding:8px 0; font-weight:600;"><?= $e['item'] ?></td>
              <td style="padding:8px 0; color:#888;"><?= date('d M', strtotime($e['date'])) ?></td>
              <td style="padding:8px 0; text-align:right; color:#27ae60; font-weight:700;">+₹<?= number_format($e['amount'], 0) ?></td>
              <td style="padding:8px 0; text-align:right;">
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= $e['id'] ?>">
                  <button type="submit" style="background:none; border:none; color:#ddd; font-size:11px; cursor:pointer;"
                    onclick="return confirm('Delete this?')">✕</button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

  </div>

  <!-- All Expenses Table -->
  <div style="background:#fff; border:1px solid #e8e8e8; border-radius:6px; padding:20px 22px; margin-bottom:30px;">

    <h2 style="margin:0 0 14px; font-size:15px; font-weight:700; color:#c0392b; border-bottom:1px solid #f0f0f0; padding-bottom:10px;">
      Expenses (<?= count($expenses) ?>) &nbsp;<span style="font-weight:400; color:#aaa; font-size:13px;">Total: ₹<?= number_format($total_expense, 0) ?></span>
    </h2>

    <?php if (empty($expenses)): ?>
      <p style="color:#bbb; font-size:13px; margin:0;">No expenses added yet.</p>
    <?php else: ?>
    <table style="width:100%; border-collapse:collapse; font-size:13px;">
      <thead>
        <tr style="background:#fafafa; border-bottom:1px solid #eee;">
          <th style="text-align:left; padding:9px 10px; color:#888; font-weight:600;">Item</th>
          <th style="text-align:left; padding:9px 10px; color:#888; font-weight:600;">Category</th>
          <th style="text-align:left; padding:9px 10px; color:#888; font-weight:600;">Date</th>
          <th style="text-align:right; padding:9px 10px; color:#888; font-weight:600;">Amount</th>
          <th style="text-align:right; padding:9px 10px; color:#888; font-weight:600;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($expenses as $e): ?>
        <tr style="border-bottom:1px solid #f5f5f5;">
          <td style="padding:9px 10px; font-weight:600;"><?= $e['item'] ?></td>
          <td style="padding:9px 10px;">
            <span style="background:#fdecea; color:#c0392b; font-size:11px; padding:2px 8px; border-radius:3px; font-weight:600;"><?= $e['category'] ?></span>
          </td>
          <td style="padding:9px 10px; color:#888;"><?= date('d M Y', strtotime($e['date'])) ?></td>
          <td style="padding:9px 10px; text-align:right; font-weight:700; color:#c0392b;">₹<?= number_format($e['amount'], 0) ?></td>
          <td style="padding:9px 10px; text-align:right;">
            <form method="POST" style="display:inline;">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $e['id'] ?>">
              <button type="submit"
                style="background:#fdecea; color:#c0392b; border:none; padding:4px 10px; border-radius:3px; font-size:12px; cursor:pointer; font-weight:600;"
                onclick="return confirm('Delete this expense?')">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>

  </div>

</div>
</body>
</html>
