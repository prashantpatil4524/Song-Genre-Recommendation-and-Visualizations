<?php
session_start();

if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

// Simple user store (array - Unit I: variables & arrays)
$users = [
    'admin' => '1234',
    'rahul' => 'pass123',
    'priya' => 'pass456'
];

$error = '';

// Unit IV: Handling HTML forms with PHP
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Unit II: User defined functions
    function validateLogin($users, $username, $password) {
        if ($username === '') return 'Please enter username.';
        if ($password === '') return 'Please enter password.';
        if (!array_key_exists($username, $users)) return 'Username not found.';
        if ($users[$username] !== $password) return 'Wrong password.';
        return '';
    }

    $error = validateLogin($users, $username, $password);

    if ($error === '') {
        $_SESSION['user'] = $username;
        header('Location: index.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login – Expense Tracker</title>
</head>
<body style="margin:0; padding:0; background:#fff; font-family:Arial, sans-serif; min-height:100vh; display:flex; align-items:center; justify-content:center;">

  <div style="width:100%; max-width:380px; padding:16px;">

    <!-- Header -->
    <div style="background:#c0392b; padding:28px 30px 22px; border-radius:6px 6px 0 0; text-align:center;">
      <p style="margin:0; color:#fff; font-size:11px; letter-spacing:2px; text-transform:uppercase;">Welcome</p>
      <h1 style="margin:6px 0 0; color:#fff; font-size:22px; font-weight:700;">Expense Tracker</h1>
    </div>

    <!-- Form box -->
    <div style="background:#fff; border:1px solid #e0e0e0; border-top:none; border-radius:0 0 6px 6px; padding:28px 30px;">

      <?php if ($error !== ''): ?>
        <div style="background:#fdecea; border-left:3px solid #c0392b; padding:10px 14px; margin-bottom:18px; border-radius:3px;">
          <p style="margin:0; color:#c0392b; font-size:13px;"><?= htmlspecialchars($error) ?></p>
        </div>
      <?php endif; ?>

      <!-- Unit IV: HTML form controls -->
      <form method="POST">

        <div style="margin-bottom:16px;">
          <label style="display:block; font-size:13px; color:#555; margin-bottom:6px; font-weight:600;">Username</label>
          <input type="text" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
            placeholder="Enter username"
            style="width:100%; box-sizing:border-box; padding:10px 12px; border:1px solid #ccc; border-radius:4px; font-size:14px; outline:none;">
        </div>

        <div style="margin-bottom:22px;">
          <label style="display:block; font-size:13px; color:#555; margin-bottom:6px; font-weight:600;">Password</label>
          <input type="password" name="password"
            placeholder="Enter password"
            style="width:100%; box-sizing:border-box; padding:10px 12px; border:1px solid #ccc; border-radius:4px; font-size:14px; outline:none;">
        </div>

        <button type="submit"
          style="width:100%; padding:11px; background:#c0392b; color:#fff; border:none; border-radius:4px; font-size:15px; font-weight:600; cursor:pointer;">
          Login
        </button>

      </form>

      <p style="margin:18px 0 0; font-size:12px; color:#aaa; text-align:center;">
        Demo: <strong>admin</strong> / <strong>1234</strong>
      </p>
    </div>

  </div>
</body>
</html>
